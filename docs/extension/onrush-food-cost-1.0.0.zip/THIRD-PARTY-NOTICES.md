# Composants et droits

Ce projet autonome n’embarque aucune dépendance npm, bibliothèque tierce, police distante ou code du SaaS Onrush. Le moteur de calcul, l’interface, les tests et les scripts de construction sont du code original créé pour ce calculateur.

Les modules intégrés de Node.js sont utilisés pour les tâches locales de construction et de test. Ils ne sont pas intégrés comme bibliothèque dans les fichiers web ou dans l’extension. Le navigateur et les logiciels éventuellement employés pour prévisualiser ou ouvrir un CSV conservent leurs propres licences et conditions.

Le nom Onrush et les éventuels signes distinctifs de SAS La Fabrique Alimentaire ne sont pas concédés par la licence MIT du code. Aucun logo ou contenu tiers ne doit être ajouté sans vérification de ses droits. Les exemples de recette sont fictifs et ne constituent pas des données clients.

Si une dépendance, une image, une police, un extrait ou un jeu de données externe est ajouté ultérieurement, relever sa provenance, sa version, sa licence et ses obligations d’attribution dans ce fichier avant diffusion. La présente notice ne concède aucun droit sur un composant futur.

## Identité Onrush et Montserrat

Pour l’icône Chrome de 128 px, le SVG officiel intact est rendu à 96 px et placé au centre avec une marge transparente de 16 px de chaque côté, conformément aux recommandations de taille du Chrome Web Store. Cette mise à taille ne modifie ni le tracé ni les couleurs de la marque.

Icône officielle Onrush : copie inchangée de `public/brand/v1/icon-light.svg`, exportée en PNG 16/48/128 pour Chrome. La marque et son logo restent exclus de la licence MIT du code. Police Montserrat variable, latin normal, copiée inchangée depuis la fonte locale officielle `app/_fonts/montserrat-latin.woff2` d’Onrush ; licence SIL Open Font License reproduite dans `MONTSERRAT-OFL.txt`. Aucun chargement de police distant.
